
from pydantic import BaseModel

class AddressBase(BaseModel):
    user_id :int
    address_line1:str
    address_line2:str
    city:str
    state:str
    postal_code:int
    phone_no:str
    country:str
    