from sqlalchemy import Column,Integer,String,ForeignKey
from sqlalchemy.orm import relationship 
from db.database import Base

class Address(Base):
    __tablename__="address"

    id =Column(Integer,primary_key=True)
    user_id=Column(Integer,ForeignKey("users.id"))
    address_line1=Column(String)
    address_line2=Column(String)
    city=Column(String)
    state=Column(String)
    postal_code=Column(Integer)
    country=Column(String)
    phone_no=Column(String)

    user = relationship("User")