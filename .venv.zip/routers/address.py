from fastapi import Depends,APIRouter
from sqlalchemy.orm import Session
from dependencies import connect_db
from models.address import Address
from schemas.address import AddressBase

address_router=APIRouter(prefix="/address",tags=["address"])

@address_router.get("/")
def get_address(db:Session=Depends(connect_db)):
    return db.query(Address).all()



@address_router.post("/address")
def add_new_address(address:AddressBase,db:Session=Depends(connect_db)):
    address=Address(**address.dict())
    db.add(address)
    db.commit()
    db.refresh(address)
    return address

