from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from models.cart import Cart
from models.cart_items import CartItem
from models.product import Product
from schemas.cart_items import CartItemCreate, CartItemOut
from dependencies import connect_db

cart_item_router = APIRouter(prefix="/cart-items", tags=["Cart Items"])

@cart_item_router.post("/{user_id}")
def add_to_cart(
    user_id: int,
    data: CartItemCreate,
    db: Session = Depends(connect_db)
):
    # Get or create cart
    cart = db.query(Cart).filter(Cart.user_id == user_id).first()
    if not cart:
        cart = Cart(user_id=user_id)
        db.add(cart)
        db.commit()
        db.refresh(cart)

    product = db.query(Product).filter(Product.id == data.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    
    item = db.query(CartItem).filter(
        CartItem.cart_id == cart.id,
        CartItem.product_id == data.product_id
    ).first()

    if item:
        item.quantity += data.quantity
    else:
        item = CartItem(
            cart_id=cart.id,
            product_id=data.product_id,
            quantity=data.quantity,
            price=(data.price if getattr(data, 'price', None) is not None else product.price)
        )
    db.add(item)

    db.commit()
    db.refresh(item)
    return item


@cart_item_router.get("/{user_id}", response_model=List[CartItemOut])
def get_cart_items(user_id: int, db: Session = Depends(connect_db)):
    """Return all cart items for a user's active cart"""
    cart = db.query(Cart).filter(Cart.user_id == user_id).first()
    if not cart:
        raise HTTPException(status_code=404, detail="Cart not found")

    items = db.query(CartItem).filter(CartItem.cart_id == cart.id).all()
    return items

@cart_item_router.put("/{item_id}")
def update_cart_item(
    item_id: int,
    data: CartItemCreate,
    db: Session = Depends(connect_db)
):
    item = db.query(CartItem).filter(CartItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Cart item not found")
    
    item.quantity = data.quantity
    if hasattr(data, 'variant_order') and data.variant_order is not None:
        item.variant_order = data.variant_order
    if getattr(data, 'price', None) is not None:
        item.price = data.price
    db.commit()
    db.refresh(item)
    return item

@cart_item_router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_from_cart(
    item_id: int,
    db: Session = Depends(connect_db)
):
    item = db.query(CartItem).filter(CartItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Cart item not found")
    
    db.delete(item)
    db.commit()
    return None